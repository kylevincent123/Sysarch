package com.tunehubapp.sysarch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysarchApplicationTests {

	@Test
	void contextLoads() {
	}

}
